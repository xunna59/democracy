<?php 
error_reporting(0);
  require_once('inc/User.php');
  require_once('inc/Message.php');
if (!isset($_SESSION['user_id']))
{
    header("Location: login");
    die();
}
$roles = $user->getUserInfo()['role'];
 if(isset($_POST['register'])){

 if ($roles == 0) {
                        if ($_POST['password'] == $_POST['confirm_password']) {
      
    $register = $user->register($_POST['email'], $_POST['name'], $_POST['password'], $_POST['state']);
      }
      else{

     header("Location: reg-admin?error=password doesn't match");
      }     
                          }else{

                             header("Location: reg-admin?unauthorised=Access Denied");

                          }

    
  }
?>

<!DOCTYPE html>
<html lang="en-US" dir="ltr">
<meta http-equiv="content-type" content="text/html;charset=utf-8" />
<head>
    <meta charset="utf-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- ===============================================-->
    <!--    Document Title-->
    <!-- ===============================================-->
    <title>Register</title>

    <!-- ===============================================-->
    <!--    Favicons-->
    <!-- ===============================================-->
  <link rel="apple-touch-icon" sizes="180x180" href="https://upload.wikimedia.org/wikipedia/commons/b/bc/Coat_of_arms_of_Nigeria.svg">
    <link rel="icon" type="image/png" sizes="32x32" href="https://upload.wikimedia.org/wikipedia/commons/b/bc/Coat_of_arms_of_Nigeria.svg">
    <link rel="icon" type="image/png" sizes="16x16" href="https://upload.wikimedia.org/wikipedia/commons/b/bc/Coat_of_arms_of_Nigeria.svg">
    <link rel="shortcut icon" type="image/x-icon" href="https://upload.wikimedia.org/wikipedia/commons/b/bc/Coat_of_arms_of_Nigeria.svg">
    <link rel="manifest" href="assets/img/favicons/manifest.json">
    <meta name="msapplication-TileImage" content="https://upload.wikimedia.org/wikipedia/commons/b/bc/Coat_of_arms_of_Nigeria.svg">
    <meta name="theme-color" content="#ffffff">
    <!-- =============================================== -->
    <!--    Stylesheets    --> 
    <!-- =============================================== -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin="">
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300;400;600;700;800;900&amp;display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../../../../../../unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link href="assets/css/theme.min.css" type="text/css" rel="stylesheet" id="style-default">
    <link href="assets/css/user.min.css" type="text/css" rel="stylesheet" id="user-style-default">

    <style>
      
      .main{

        background-image: url(assets/img/nigeria.jpg);
         background-repeat: no-repeat;
          background-size: auto;
          background-attachment: fixed;
  background-position: center; 
        opacity: 0.9;
      }

    </style>
    
  </head>

  <body>
    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    <main class="main" id="top">
      <div class="container-fluid px-0" data-layout="container">
        <div class="container">
          <div class="row flex-center min-vh-100 py-5">
            <div class="col-sm-10 col-md-8 col-lg-5 col-xl-5 col-xxl-3"><a class="d-flex flex-center text-decoration-none mb-4" href="index.html">
                <div class="d-flex align-items-center fw-bolder fs-5 d-inline-block"><img src="assets/img/icons/logo.png" alt="phoenix" width="58" /></div>
              </a>
              <div class="text-center mb-7">
                <h3>Register State Admin</h3>
               
              </div>

              <!-- <div class="position-relative mt-4">
                <hr class="bg-200" />
                <div class="divider-content-center">or use email</div>
              </div> -->
              <form id="loginForm" method="post" action="">
                
                 <div class="msg text-danger"><?php echo $message->message();?></div>


                  <div class="mb-3 text-start ">
                <label class="form-label text-success" for="email">Name</label>
                <div class="form-icon-container inputblock">

                  <input class="form-control form-icon-input " id="email" name="name" type="text" autocomplete="email" required placeholder="Enter Name" />
                  <span class="fas fa-user text-900 fs--1 form-icon"></span>
                </div>
              </div>


              <div class="mb-3 text-start ">
                <label class="form-label text-success" for="email">Email address</label>
                <div class="form-icon-container inputblock">

                  <input class="form-control form-icon-input " id="email" name="email" type="email" autocomplete="email" required placeholder="Enter your email" />
                  <span class="fas fa-envelope text-900 fs--1 form-icon"></span>
                </div>
              </div>

               <div class="mb-3 text-start ">
                <label class="form-label text-success" for="">State</label>
                <div class="form-icon-container inputblock">

                  <select name="state" id="state" class="form-select" required>
                           <option value="" selected="selected">- Select -</option>
              <option value="Abia">Abia</option>
              <option value="Adamawa">Adamawa</option>
              <option value="AkwaIbom">AkwaIbom</option>
              <option value="Anambra">Anambra</option>
              <option value="Bauchi">Bauchi</option>
              <option value="Bayelsa">Bayelsa</option>
              <option value="Benue">Benue</option>
              <option value="Borno">Borno</option>
              <option value="Cross River">Cross River</option>
              <option value="Delta">Delta</option>
              <option value="Ebonyi">Ebonyi</option>
              <option value="Edo">Edo</option>
              <option value="Ekiti">Ekiti</option>
              <option value="Enugu">Enugu</option>
              <option value="FCT">FCT</option>
              <option value="Gombe">Gombe</option>
              <option value="Imo">Imo</option>
              <option value="Jigawa">Jigawa</option>
              <option value="Kaduna">Kaduna</option>
              <option value="Kano">Kano</option>
              <option value="Katsina">Katsina</option>
              <option value="Kebbi">Kebbi</option>
              <option value="Kogi">Kogi</option>
              <option value="Kwara">Kwara</option>
              <option value="Lagos">Lagos</option>
              <option value="Nasarawa">Nasarawa</option>
              <option value="Niger">Niger</option>
              <option value="Ogun">Ogun</option>
              <option value="Ondo">Ondo</option>
              <option value="Osun">Osun</option>
              <option value="Oyo">Oyo</option>
              <option value="Plateau">Plateau</option>
              <option value="Rivers">Rivers</option>
              <option value="Sokoto">Sokoto</option>
              <option value="Taraba">Taraba</option>
              <option value="Yobe">Yobe</option>
              <option value="Zamfara">Zamafara</option>


                          </select>
                 
                </div>
              </div>


              <div class="mb-3 text-start">
                <label class="form-label text-success" for="password">Password</label>
                <div class="form-icon-container inputblock">
                  <input class="form-control form-icon-input " id="password" name="password" type="password" autocomplete="current-password" required placeholder="Enter your password"  />
                  <span class="fas fa-lock text-900 fs--1 form-icon"></span></div>
              </div>


               <div class="mb-3 text-start">
                <label class="form-label text-success" for="password">Confirm Password</label>
                <div class="form-icon-container inputblock">
                  <input class="form-control form-icon-input " id="password" name="confirm_password" type="password" autocomplete="current-password" required placeholder="Enter your password"  />
                  <span class="fas fa-lock text-900 fs--1 form-icon"></span></div>
              </div>

              <div class="row flex-between-center mb-7">
                
               
              </div>
              <button class="btn btn-danger w-100 mb-3" type="submit" name="register">Sign Up</button>
            </form>

<!--               <div class="text-center"><a class="fs--1 fw-bold" href="sign-up.html">Create an account</a></div>
 -->            </div>
          </div>
        </div>
      </div>
    </main><!-- ===============================================-->
    <!--    End of Main Content-->
    <!-- ===============================================-->

  <script src="<?php echo dirname($_SERVER['PHP_SELF']) . '/script.js' ?>"></script>


    <!-- ===============================================-->
    <!--    JavaScripts-->
    <!-- ===============================================-->
    <script src="vendors/popper/popper.min.js"></script>
    <script src="vendors/bootstrap/bootstrap.min.js"></script>
    <script src="vendors/anchorjs/anchor.min.js"></script>
    <script src="vendors/is/is.min.js"></script>
    <script src="vendors/fontawesome/all.min.js"></script>
    <script src="vendors/lodash/lodash.min.js"></script>
    <script src="../../../../../../polyfill.io/v3/polyfill.min58be.js?features=window.scroll"></script>
    <script src="vendors/list.js/list.min.js"></script>
    <script src="vendors/feather-icons/feather.min.js"></script>
    <script src="vendors/dayjs/dayjs.min.js"></script>
    <script src="assets/js/phoenix.js"></script>
  </body>


</html>