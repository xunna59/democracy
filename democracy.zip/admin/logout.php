<?php
  require_once('./inc/User.php');

$user->logout();