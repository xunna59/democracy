<?php include('includes/header.php') ?>
    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    
      
     <?php include('includes/nav-bar.php') ?>
      <?php include('includes/top-bar.php') ?>
    
    <label>Camera</label>
    <hr>
               

                  <!-- card header starts here -->
                  
                 <!--  card header ends here -->

                  <!-- card body starts here -->

   <center>                     
<div class="col-12" id="my_camera">
      

    </div> 
    <div class="col-12" id="results" style=" visibility: hidden; position: absolute;">
      

    </div> 
    <br>

    <div class="d-flex justify-content-center">
    
    <button class="btn btn-success m-2" type="button" onclick="saveSnap();">Capture</button>
      <a class="nav-link" href="video-upload"> <button class="btn btn-danger m-2" type="button" >Video Upload</button></a>

    </div>  


    </center>        

















                  <!-- card body ends here -->





 



























   
    
    </div>  
    <?php include('includes/footer.php') ?>
