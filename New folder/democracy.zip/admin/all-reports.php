<?php include('includes/header.php') ?>
    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    
      
     <?php include('includes/nav-bar.php') ?>
      <?php include('includes/top-bar.php') ?>
    
    <label>Reports</label>
    <hr>
               <div class="mx-lg-n4 mt-3">


                   <div class="col-12 col-xl-12 col-xxl-12">
                <div class="card h-100">
                  <div class="card-body">
                    <div class="card-title mb-1">
                      <h3 class="text-1100">Activity</h3>
                    </div>

                    <p class="text-700 mb-4">Reports by States</p>
                    <div class="timeline-vertical">
          <?php



$qry="SELECT DISTINCT state FROM reports ORDER BY state ASC";

// proceed only if a query is executed
if($result = $sonawap->query($qry)){

  if($result->num_rows > 0){
    while ($row = $result->fetch_assoc()) {
      


?>
<hr>
 <div class="timeline-item position-relative">

                        <div class="row g-md-3">
                          <div class="col-12 col-md-auto d-flex">
                            <div class="timeline-start-item order-1 order-md-0 me-md-4">
                              <p class="fs--2 fw-semi-bold text-600"><?php  print_r ($row['datecreated']); ?></p>
                            </div>
                            <div class="timeline-icon-item position-md-relative me-3 me-md-0">
                              <div class="icon-item icon-item-sm border rounded-7 shadow-none bg-primary-200"><span class="text-primary fas fa-chess"></span></div>
                            </div>
                          </div>

                          <div class="col">
                            <div class="timeline-content-item ps-7 ps-md-3">
                              <h5 class="fs--1"><?php  print_r($row['state']); ?></h5>
                              <a href="view-report?report=<?php print_r($row['state']);  ?>"><p class="fs--1"><span class="fw-semi-bold text-primary">View Report</span></p></a>
                              
                            </div>
                          </div>
                        </div>
                      </div>
 



 <?php 

                  }
}else{


echo '<hr><p class="text-danger d-flex justify-content-center">No Record Found</p><hr>';


}

}


?>                   




                    </div>




                  </div>
                </div>
              </div>





               </div>




         
    </div>
    </div>
    </div>  
    <?php include('includes/footer.php') ?>
