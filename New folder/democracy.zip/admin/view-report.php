<?php include('includes/header.php') ?>
    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    
      
     <?php include('includes/nav-bar.php') ?>
      <?php include('includes/top-bar.php') ?>
    
   <div class="content">
          <nav class="mb-2" aria-label="breadcrumb">
            <ol class="breadcrumb mb-0">
              <li class="breadcrumb-item"><a href="all-reports">State</a></li>
              <li class="breadcrumb-item active"><?php echo $_GET['report']; ?></li>
            </ol>
          </nav>
          <h2 class="mb-5"><?php echo $_GET['report']; ?> State</h2>
         
          <?php

$getstate = $_GET['report'];

$qry="SELECT * FROM reports WHERE state = '$getstate' ORDER BY lga ASC";

// proceed only if a query is executed
if($result = $sonawap->query($qry)){

  if($result->num_rows > 0){
    while ($row = $result->fetch_assoc()) {
      


?>
 <div class="mx-n4 mx-lg-n6">
            <div class="d-flex align-items-center justify-content-between py-3 border-300 px-lg-6 px-4 notification-card border-top bg-soft">
              <div class="d-flex">
                <div class="avatar avatar-xl  mb-5 me-3">
                  <img class="rounded-circle" src="assets/img/icons/logo.png" alt="" />
                </div>
                <div class="me-3 flex-1 mt-2">
                  <h4 class="fs--1 text-black"><?php print_r($row['lga']); ?> L.G.A</h4>
                  <p class="fs--1 text-1000">Ward Number: <?php print_r($row['wardno']); ?></p>
                   <p class="fs--1 text-1000">Accredited Votes: <span class="text-danger"> <?php print_r($row['accrdvotes']); ?></span></p>
                     <p class="fs--1 text-1000">Valid Votes: <span class="text-danger"> <?php print_r($row['validvotes']); ?></span></p>
                       <p class="fs--1 text-1000">Name of INEC Official: <span class="text-primary"><?php print_r($row['officialname']); ?></span></p>
                  <p class="text-800 fs--1 mb-0"><span class="me-1 fas fa-clock"></span><?php print_r($row['datecreated']); ?></p>
                </div>
              </div>
             <!--  <div class="font-sans-serif"><button class="btn fs--2 btn-sm dropdown-toggle dropdown-caret-none transition-none notification-dropdown-toggle" type="button" data-bs-toggle="dropdown" data-boundary="window" aria-haspopup="true" aria-expanded="false" data-bs-reference="parent"><span class="fas fa-ellipsis-h fs--2"></span></button>
                <div class="dropdown-menu dropdown-menu-end py-2"><a class="dropdown-item" href="#!">Mark as unread</a></div>
              </div> -->
            </div>
          </div>



 <?php 

                  }
}else{


echo '<hr><p class="text-danger d-flex justify-content-center">No Record Found</p><hr>';


}

}


?>                   




                    </div>



    <?php include('includes/footer.php') ?>
