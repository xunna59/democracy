<?php include('includes/header.php') ?>
    <!-- ===============================================-->
    <!--    Main Content-->
    <!-- ===============================================-->
    
      
     <?php include('includes/nav-bar.php') ?>
      <?php include('includes/top-bar.php') ?>
        
 <?php

$sql = "SELECT * FROM lgausers";
 
$mysqliStatus = $sonawap->query($sql);
 
$rows_count_value = mysqli_num_rows($mysqliStatus);
 
 


 ?>
        

          <div class="pb-5">
            <div class="row g-4">
              <div class="col-12 col-xxl-6">
                <div class="mb-8">
                  <h2 class="mb-2">Labour Party</h2>
                  <h5 class="text-700 fw-semi-bold">Dashboard Summary</h5>
                </div>
                <div class="row align-items-center g-4">
                  <div class="col-12 col-md-auto">
                    <div class="d-flex align-items-center"><img src="assets/img/icons/illustrations/4.png" alt="" height="46" width="46" />
                      <div class="ms-3">
                        <h4 class="mb-0"><?php echo $rows_count_value; ?></h4>
                        <p class="text-800 fs--1 mb-0">Registered Accounts</p>
                      </div>
                    </div>
                  </div>

                   <?php

$sql = "SELECT * FROM reports";
 
$mysqliStatus = $sonawap->query($sql);
 
$reports = mysqli_num_rows($mysqliStatus);
 
 


 ?>
                  <div class="col-12 col-md-auto">
                    <div class="d-flex align-items-center"><img src="assets/img/icons/illustrations/2.png" alt="" height="46" width="46" />
                      <div class="ms-3">
                        <h4 class="mb-0"><?php echo $reports; ?></h4>
                        <p class="text-800 fs--1 mb-0">Total Reports</p>
                      </div>
                    </div>
                  </div>

                   <?php

$sql = "SELECT * FROM webcam";
 
$mysqliStatus = $sonawap->query($sql);
 
$camerauploads = mysqli_num_rows($mysqliStatus);
 
 


 ?>
                  <div class="col-12 col-md-auto">
                    <div class="d-flex align-items-center"><img src="assets/img/icons/illustrations/3.png" alt="" height="46" width="46" />
                      <div class="ms-3">
                        <h4 class="mb-0"><?php echo $camerauploads; ?></h4>
                        <p class="text-800 fs--1 mb-0">Camera Uploads</p>
                      </div>
                    </div>
                  </div>
                </div>
                <hr class="bg-200 mb-6 mt-4" />
                
              </div>
             
            </div>
          </div>



         <!-- 
          <div class="row gx-6">
            <div class="col-12 col-xl-6">
             
            





              <div class="d-flex align-items-center justify-content-between py-2 fs--1 mb-1">
                <p class="mb-0 d-none d-sm-block me-3 fw-semi-bold text-900" data-list-info="">1 to 5 <span class="text-600"> Items of </span> 15</p><a class="fw-semi-bold" href="#!" data-list-view="*">View all<span class="fas fa-angle-right ms-2" data-fa-transform="down-1"></span></a>
              </div>
            </div>
            <div class="col-12 col-xl-6">
              <div class="mx-n4 mx-lg-n6 ms-xl-0 h-100">
                <div class="h-100 w-100">
                  <div class="h-100 bg-white" id="map" style="min-height: 300px;"></div>
                </div>
              </div>
            </div>
          </div> -->
          
         <?php include('includes/footer.php') ?>
